
import React, { useCallback, useState } from 'react';
import Footer from '../../component/layouts/Footer';
import { Link } from 'react-router-dom';
import { useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { clearHistory, fetchHistoryByUserId } from '../../services/historyService';
import { fetchTrip } from '../../services/tripServices';
import { fetchPayment } from '../../services/paymentService';
import { deleteMessage, getUserMessages } from '../../services/messageServices';
import { InvoiceButton } from '../../component/layouts/InvoiceButton';
// import CancellationManager from '../../component/layouts/CancelTrip';
import { getUserCancellations } from '../../services/cancellationService';
import { ActionButtons, ImageStatusBadge, imageTint, PriceLabel } from '../../component/common/ImageStatusBadge';


const HistoryPage = () => {
    const { user } = useAuth();


    const [history, setHistory] = useState([]);
    const [trips, setTrips] = useState([]);
    const [payments, setPayments] = useState([]);
    const [cancellations, setCancellations] = useState([]);
    const [userMessages, setUserMessages] = useState([]);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('history');
    useEffect(() => {
        const queryParams = new URLSearchParams(window.location.search);
        const tab = queryParams.get("active");
        setActiveTab(tab || "history");
    }, [])
    console.log("activeTab : ", activeTab)



    // const name = myUrl.searchParams.get('active');
    // setActiveTab(name)
    const [showClearConfirm, setShowClearConfirm] = useState(false);
    const [showSupportModal, setShowSupportModal] = useState(false);
    const [selectedTrip, setSelectedTrip] = useState(null);
    const [filterState, setFilterState] = useState({ all: true, created: false, joined: false });

    const loadData = useCallback(async () => {
        if (!user?._id) { setLoading(false); return; }
        try {
            const [h, t, p, m, c] = await Promise.all([
                fetchHistoryByUserId(user._id),
                fetchTrip(),
                fetchPayment(),
                getUserMessages(user._id),
                getUserCancellations(),
            ]);
            setHistory(h.history || []);
            setTrips(t.trip);
            setPayments(p.payments || []);
            setUserMessages(m.data);
            setCancellations(c || []);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, [user]);
    console.log("userMessages :", userMessages)
    useEffect(() => { if (user?._id) loadData(); }, [user]);

    const handleCheckboxChange = (name) => {
        if (name === 'all') {
            setFilterState({ all: true, created: false, joined: false });
        } else {
            setFilterState({ ...filterState, all: false, [name]: !filterState[name] });
        }
    };

    const filteredHistory = history.filter(h => {
        if (filterState.all) return true;
        if (filterState.created && h.type === 'CREATED') return true;
        if (filterState.joined && h.type === 'JOINED') return true;
        return false;
    });

    const handleClearHistory = async () => {
        try {
            if (activeTab === 'history') {
                await clearHistory(user._id);
                setHistory([]);
            } else {
                await deleteMessage(user._id);
                setUserMessages([]);
            }
            setShowClearConfirm(false);
        } catch (err) {
            console.error(err);
            alert(`Failed to clear ${activeTab === 'history' ? 'history' : 'support requests'}`);
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-slate-50 flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-slate-50 flex flex-col">
            <main className="max-w-5xl mx-auto px-4 py-12 flex-grow w-full">

                {/* Header */}
                <div className="flex flex-col md:flex-row justify-between items-end gap-6 mb-12">
                    <div>
                        <h1 className="text-5xl font-black text-slate-900 mb-2 tracking-tight">Travel Journey</h1>
                        <p className="text-xl text-slate-500 font-medium">Relive your planned and joined adventures.</p>
                    </div>
                    <button
                        onClick={() => setShowClearConfirm(true)}
                        className="bg-white text-rose-500 border-2 border-rose-100 px-8 py-3 rounded-2xl font-black hover:bg-rose-50 transition-all text-sm uppercase tracking-widest shadow-lg shadow-rose-100"
                    >
                        {activeTab === 'history' ? 'Clear My History' : 'Clear Support Requests'}
                    </button>
                </div>

                {/* Tabs */}
                <div className="flex gap-4 mb-8">
                    <button
                        onClick={() => setActiveTab('history')}
                        className={`px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-xs transition-all ${activeTab === 'history' ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' : 'bg-white text-slate-400 border border-slate-100 hover:bg-slate-50'}`}
                    >
                        Trip History
                    </button>
                    <button
                        onClick={() => setActiveTab('support')}
                        className={`px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-xs transition-all flex items-center gap-3 ${activeTab === 'support' ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' : 'bg-white text-slate-400 border border-slate-100 hover:bg-slate-50'}`}
                    >
                        Support Requests ({userMessages?.length})
                        {userMessages.some(m => m?.status === 'RESOLVED') && (
                            <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                        )}
                    </button>
                </div>

                {/* ── TRIP HISTORY TAB ──────────────────────────────────────── */}
                {activeTab === 'history' ? (
                    <>
                        {/* Filter */}
                        <div className="flex flex-wrap items-center gap-8 mb-12 bg-white p-8 rounded-[32px] shadow-sm border border-slate-100">
                            <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Filter Records:</span>
                            {[
                                { key: 'all', label: 'All Trips' },
                                { key: 'created', label: 'Created Trip' },
                                { key: 'joined', label: 'Joined Trips' },
                            ].map(({ key, label }) => (
                                <label key={key} className="flex items-center gap-3 cursor-pointer group">
                                    <input
                                        type="checkbox"
                                        checked={filterState[key]}
                                        onChange={() => handleCheckboxChange(key)}
                                        className="w-6 h-6 rounded-lg border-2 border-slate-200 text-indigo-600 focus:ring-indigo-500 transition-all cursor-pointer"
                                    />
                                    <span className={`font-bold transition-all ${filterState[key] ? 'text-indigo-600' : 'text-slate-500 group-hover:text-slate-800'}`}>
                                        {label}
                                    </span>
                                </label>
                            ))}
                        </div>

                        {filteredHistory?.length === 0 ? (
                            <div className="bg-white rounded-[48px] p-24 text-center border border-slate-100 shadow-xl">
                                <div className="text-8xl mb-8 opacity-20">🏜️</div>
                                <h2 className="text-3xl font-black text-slate-900 mb-4">No records found</h2>
                                <p className="text-slate-500 font-medium mb-10 max-w-sm mx-auto">Either you haven&apos;t booked anything yet or the filters are active.</p>
                                <Link to="/join-trip" className="bg-indigo-600 text-white px-12 py-5 rounded-3xl font-black hover:bg-indigo-700 shadow-xl shadow-indigo-100 inline-block transition-all uppercase tracking-widest text-sm">
                                    Discover Tours
                                </Link>
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 gap-8">
                                {filteredHistory?.map(item => {
                                    const trip = trips.find(t => t._id === item?.tripId?._id);
                                    if (!trip) return null;

                                    const payment = payments?.find(p => {
                                        const pid = p?.tripId?._id || p?.tripId;
                                        return pid?.toString() === trip?._id?.toString()
                                            && p?.userId._id?.toString() === user?._id?.toString();
                                    });

                                    // Find any cancellation for this payment
                                    const cancellation = cancellations.find(c =>
                                        c?.paymentId?._id?.toString() === payment?._id?.toString()
                                        || c?.paymentId?.toString() === payment?._id?.toString()
                                    );

                                    const cancelStatus = cancellation?.status || null;

                                    return (
                                        <div
                                            key={item?._id}
                                            className={" overflow-hidden shadow-sm hover:shadow-2xl flex flex-col md:flex-row transition-all group rounded-4xl"}
                                        // className={`bg-white rounded-[40px] overflow-hidden shadow-sm hover:shadow-2xl border border-slate-100 flex flex-col md:flex-row transition-all group border-l-8 ${borderColor(cancelStatus)}`}
                                        >
                                            {/* ── Image panel ─────────────────────────────────── */}
                                            <div className="md:w-80 h-48 md:h-auto overflow-hidden relative flex-shrink-0">
                                                <img
                                                    src={trip?.images[0]}
                                                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                                                    alt=""
                                                />

                                                {/* Tint overlay for cancelled/pending */}
                                                {cancelStatus && (
                                                    <div className={`absolute inset-0 ${imageTint(cancelStatus)}`} />
                                                )}

                                                {/* Trip type badge (top-left) */}
                                                <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-md px-4 py-1.5 rounded-full text-[10px] font-black text-indigo-600 uppercase tracking-widest shadow-md z-10">
                                                    {item?.type === 'CREATED' ? 'AI Planned' : 'Community'}
                                                </div>

                                                {/* Status badge (bottom-centre) */}
                                                <ImageStatusBadge status={cancelStatus} />
                                            </div>

                                            {/* ── Content panel ───────────────────────────────── */}
                                            <div className="flex-grow p-10 flex flex-col justify-between  ">
                                                <div>
                                                    {/* Title + price row */}
                                                    <div className="flex justify-between items-start mb-6">
                                                        <div>
                                                            <h3 className="text-3xl font-black text-slate-900">{trip?.to}</h3>
                                                            <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[0.2em] mt-2">
                                                                {trip?.from} &bull; {trip?.startDate}
                                                            </p>
                                                        </div>
                                                        <PriceLabel
                                                            status={cancelStatus}
                                                            price={trip?.price}
                                                            type={item?.type}
                                                        />
                                                    </div>

                                                    {/* Info grid */}
                                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6 py-6 border-y border-slate-100">
                                                        <div>
                                                            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Departure</p>
                                                            <p className="text-sm font-bold text-slate-800">{new Date(trip?.startDate).toLocaleDateString()}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Travel Mode</p>
                                                            <p className="text-sm font-bold text-slate-800">{trip?.transportMode}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Ref ID</p>
                                                            <p className="text-sm font-bold text-slate-800">#{item?._id?.slice(-6)?.toUpperCase()}</p>
                                                        </div>
                                                        <div>
                                                            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Agency</p>
                                                            <p className="text-sm font-bold text-slate-800">
                                                                {trip?.description?.includes('Organized by')
                                                                    ? trip?.description?.split('.')[0].replace('Organized by ', '')
                                                                    : 'AI Planner'}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* ── Action buttons (smart, based on cancel status) */}
                                                <ActionButtons
                                                    status={cancelStatus}
                                                    cancellation={cancellation}
                                                    trip={trip}
                                                    payment={payment}
                                                    item={item}
                                                    onSupport={(t) => { setSelectedTrip(t); setShowSupportModal(true); }}
                                                    onLoadData={loadData}
                                                />
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )}
                    </>
                ) : (
                    /* ── SUPPORT TAB ──────────────────────────────────────────── */
                    <div className="space-y-12">
                        <div className="grid grid-cols-1 gap-6">
                            {userMessages.length === 0 ? (
                                <div className="bg-white rounded-[48px] p-24 text-center border border-slate-100 shadow-xl">
                                    <div className="text-8xl mb-8 opacity-20">📩</div>
                                    <h2 className="text-3xl font-black text-slate-900 mb-4">No requests found</h2>
                                    <p className="text-slate-500 font-medium mb-10 max-w-sm mx-auto">You haven&apos;t raised any support tickets yet.</p>
                                </div>
                            ) : (
                                userMessages.map(msg => (
                                    <div key={msg?._id} className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100">
                                        <div className="flex justify-between items-start mb-6">
                                            <div className="flex items-center gap-4">
                                                <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center text-xl">🎫</div>
                                                <div>
                                                    <h3 className="font-black text-slate-900 text-lg">{msg.subject}</h3>
                                                    <p className="text-xs font-bold text-slate-400">Raised on {new Date(msg.createdAt).toLocaleString('en-GB')}</p>
                                                </div>
                                            </div>
                                            <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${msg.status === 'RESOLVED' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                                                {msg.status}
                                            </span>
                                        </div>
                                        <div className="bg-slate-50 p-6 rounded-2xl">
                                            <p className="text-slate-700 font-medium leading-relaxed">{msg.message}</p>
                                        </div>
                                        {msg.status === 'RESOLVED' && (
                                            <div className="mt-6 p-6 bg-emerald-50 rounded-2xl border border-emerald-100">
                                                <div className="flex items-center gap-2 text-emerald-600 font-black text-[10px] uppercase tracking-[0.2em] mb-3">
                                                    <span className="w-5 h-5 bg-emerald-500 text-white rounded-full flex items-center justify-center text-[10px]">✓</span>
                                                    Resolution Details
                                                </div>
                                                <p className="text-slate-700 font-medium leading-relaxed italic">
                                                    {msg?.resolution || "This request has been successfully resolved by our support team."}
                                                </p>
                                            </div>
                                        )}
                                        {console.log("msg : ", msg)}
                                    </div>
                                ))
                            )}
                        </div>

                        {/* FAQ */}
                        <div className="mt-20">
                            <div className="text-center mb-16">
                                <h2 className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.4em] mb-4">Support Center</h2>
                                <h3 className="text-4xl font-black text-slate-900 tracking-tighter">Frequently Asked Questions</h3>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {[
                                    { q: "How does the AI trip planning work?", a: "Our AI analyzes thousands of data points including weather, local events, and user preferences to generate a custom itinerary in seconds." },
                                    { q: "Can I modify my itinerary after it's generated?", a: "Yes! You can manually edit any part of your trip, add new stops, or ask the AI to regenerate specific days." },
                                    { q: "Is my payment information secure?", a: "Absolutely. We use industry-standard encryption and secure payment gateways to ensure your data is always protected." },
                                    { q: "Do you offer group discounts?", a: "We do! For groups of 10 or more, please contact our corporate travel team for special rates." }
                                ].map((faq, i) => (
                                    <div key={i} className="bg-white p-10 rounded-[40px] border border-slate-100 shadow-sm hover:shadow-md transition-all">
                                        <h4 className="text-xl font-black text-slate-900 mb-4">{faq.q}</h4>
                                        <p className="text-slate-500 font-medium leading-relaxed text-sm">{faq.a}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}
            </main>

            {/* ── Clear confirm modal ───────────────────────────────────────── */}
            {showClearConfirm && (
                <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-md" onClick={() => setShowClearConfirm(false)} />
                    <div className="relative bg-white rounded-[48px] p-12 max-w-md w-full text-center shadow-2xl border-8 border-slate-50">
                        <div className="w-24 h-24 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                        </div>
                        <h3 className="text-3xl font-black text-slate-900 mb-4">Clear History?</h3>
                        <p className="text-slate-500 font-medium mb-10 leading-relaxed text-sm">This will permanently delete your booking records. This action cannot be undone.</p>
                        <div className="flex flex-col gap-4">
                            <button onClick={handleClearHistory} className="w-full bg-rose-500 text-white py-4 rounded-3xl font-black hover:bg-rose-600 transition-all shadow-xl shadow-rose-100 uppercase tracking-[0.2em] text-xs">
                                Yes, Clear All
                            </button>
                            <button onClick={() => setShowClearConfirm(false)} className="w-full bg-slate-100 text-slate-600 py-4 rounded-3xl font-bold hover:bg-slate-200 transition-all uppercase tracking-[0.2em] text-xs">
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* ── Support modal ─────────────────────────────────────────────── */}
            {showSupportModal && selectedTrip && (
                <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4">
                    <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-md" onClick={() => setShowSupportModal(false)} />
                    <div className="relative bg-white rounded-[48px] p-12 max-w-lg w-full shadow-2xl border-8 border-indigo-50">
                        <div className="flex justify-between items-start mb-8">
                            <div>
                                <h3 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Need Help?</h3>
                                <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest mt-2">Reference ID: #{selectedTrip.refId?.slice(-6)?.toUpperCase()}</p>
                            </div>
                            <button onClick={() => setShowSupportModal(false)} className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 hover:bg-rose-50 hover:text-rose-500 transition-all">✕</button>
                        </div>
                        <div className="space-y-6 mb-10">
                            <div className="p-6 bg-indigo-50 rounded-3xl border border-indigo-100">
                                <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-3">Trip Destination</p>
                                <p className="text-xl font-black text-indigo-900">{selectedTrip?.to}</p>
                            </div>
                            <div className="grid grid-cols-1 gap-4">
                                <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-xl shadow-sm">📧</div>
                                    <div>
                                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Support Email</p>
                                        <p className="font-bold text-slate-700">support@tripplanner.ai</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-xl shadow-sm">📞</div>
                                    <div>
                                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">24/7 Helpline</p>
                                        <p className="font-bold text-slate-700">+91 98765 43210</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="flex flex-col gap-4">
                            <Link to="/contact" className="w-full bg-indigo-600 text-white py-5 rounded-3xl font-black text-center hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 uppercase tracking-widest text-xs">
                                Raise a Support Ticket
                            </Link>
                            <button onClick={() => setShowSupportModal(false)} className="w-full bg-slate-100 text-slate-600 py-5 rounded-3xl font-bold hover:bg-slate-200 transition-all uppercase tracking-widest text-xs">
                                Close
                            </button>
                        </div>
                        <p className="mt-8 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">Our team typically responds within 2–4 hours.</p>
                    </div>
                </div>
            )}

            <Footer />
        </div>
    );
};

export default HistoryPage;
















// import React, { useCallback, useState } from 'react';
// import Footer from '../../component/layouts/Footer';
// import { Link } from 'react-router-dom';
// import { useEffect } from 'react';
// import { useAuth } from '../../context/AuthContext';
// import { clearHistory, fetchHistoryByUserId } from '../../services/historyService';
// import { fetchTrip } from '../../services/tripServices';
// import { fetchPaymentByUserId } from '../../services/paymentService';
// import { deleteMessage, getUserMessages } from '../../services/messageServices';
// import { InvoiceButton } from '../../component/layouts/InvoiceButton';
// import CancellationManager from '../../component/layouts/CancelTrip';
// import { getUserCancellations } from '../../services/cancellationService';
// // import { ImageStatusBadge, imageTint, PriceLabel } from '../../component/common/ImageStatusBadge';
// import { ActionButtons, ImageStatusBadge, imageTint, PriceLabel } from '../../component/common/ImageStatusBadge';

// // ─── Status badge shown over the trip image ───────────────────────────────────
// const ImageStatusBadge = ({ status }) => {
//     if (!status) return null;

//     const map = {
//         PENDING:  { label: 'PENDING',   bg: 'bg-amber-500',   text: 'text-white' },
//         APPROVED: { label: 'CANCELLED', bg: 'bg-rose-500',    text: 'text-white' },
//         REJECTED: { label: 'REJECTED',  bg: 'bg-slate-700',   text: 'text-white' },
//     };
//     const cfg = map[status];
//     if (!cfg) return null;

//     return (
//         <div className={`absolute bottom-4 left-1/2 -translate-x-1/2 ${cfg.bg} ${cfg.text} px-5 py-1.5 rounded-full text-[11px] font-black uppercase tracking-widest shadow-lg z-10`}>
//             {cfg.label}
//         </div>
//     );
// };

// // ─── Overlay tint on the image when cancelled/pending ────────────────────────
// const imageTint = (status) => {
//     if (status === 'APPROVED') return 'bg-rose-300/60';
//     if (status === 'PENDING')  return 'bg-amber-200/40';
//     return '';
// };

// // ─── Left border colour ───────────────────────────────────────────────────────
// const borderColor = (status) => {
//     if (status === 'APPROVED') return 'border-l-rose-400';
//     if (status === 'PENDING')  return 'border-l-amber-400';
//     if (status === 'REJECTED') return 'border-l-slate-400';
//     return 'border-l-indigo-600';
// };

// // ─── Price label (top-right) ──────────────────────────────────────────────────
// const PriceLabel = ({ status, price, type }) => {
//     if (status === 'APPROVED') {
//         return (
//             <div className="text-right">
//                 <p className="text-2xl font-black text-slate-900 leading-none">₹{price?.toLocaleString()}</p>
//                 <p className="text-[10px] font-black uppercase tracking-widest mt-2 text-emerald-500">Refund Processed</p>
//             </div>
//         );
//     }
//     if (status === 'PENDING') {
//         return (
//             <div className="text-right">
//                 <p className="text-2xl font-black text-slate-900 leading-none">₹{price?.toLocaleString()}</p>
//                 <p className="text-[10px] font-black uppercase tracking-widest mt-2 text-amber-500">Cancel Pending</p>
//             </div>
//         );
//     }
//     return (
//         <div className="text-right">
//             <p className="text-2xl font-black text-slate-900 leading-none">₹{price?.toLocaleString()}</p>
//             <p className={`text-[10px] font-bold uppercase tracking-widest mt-2 ${type === 'JOINED' ? 'text-emerald-500' : 'text-slate-400'}`}>
//                 {type === 'JOINED' ? 'Paid & Booked' : 'Saved Plan'}
//             </p>
//         </div>
//     );
// };

// // ─── Bottom action buttons ────────────────────────────────────────────────────
// const ActionButtons = ({ status, cancellation, trip, payment, item, onSupport, onLoadData }) => {

//     // ── APPROVED: Refund completed row ────────────────────────────────────────
//     if (status === 'APPROVED') {
//         return (
//             <div className="flex gap-4 mt-8 flex-wrap">
//                 <Link
//                     to={`/trip/${trip?._id}`}
//                     className="flex-1 text-center bg-indigo-600 text-white py-4 rounded-2xl font-black hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 uppercase tracking-widest text-xs min-w-[140px]"
//                 >
//                     View Full Details
//                 </Link>

//                 {/* Refund completed badge — styled like the screenshot green button */}
//                 <div className="flex flex-col items-center justify-center px-6 py-3 rounded-2xl border-2 border-emerald-200 bg-emerald-50 min-w-[160px]">
//                     <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Refund Completed</span>
//                     {cancellation?.paymentId?.refundTxnId && (
//                         <span className="text-[9px] font-bold text-emerald-500 mt-0.5">
//                             TXN: #{cancellation.paymentId.refundTxnId}
//                         </span>
//                     )}
//                 </div>

//                 <button
//                     onClick={() => onSupport({ ...trip, refId: item._id })}
//                     className="px-8 bg-slate-900 text-slate-100 border border-slate-100 rounded-2xl font-bold hover:bg-slate-950 hover:shadow-lg transition-all uppercase tracking-widest text-[10px]"
//                 >
//                     Support
//                 </button>
//             </div>
//         );
//     }

//     // ── PENDING: Request submitted row ────────────────────────────────────────
//     if (status === 'PENDING') {
//         return (
//             <div className="flex gap-4 mt-8 flex-wrap">
//                 <Link
//                     to={`/trip/${trip?._id}`}
//                     className="flex-1 text-center bg-indigo-600 text-white py-4 rounded-2xl font-black hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 uppercase tracking-widest text-xs min-w-[140px]"
//                 >
//                     View Full Details
//                 </Link>

//                 {/* Requested successfully chip */}
//                 <div className="flex flex-col items-center justify-center px-6 py-3 rounded-2xl border-2 border-amber-200 bg-amber-50 min-w-[160px]">
//                     <span className="text-[10px] font-black text-amber-600 uppercase tracking-widest">Requested Successfully</span>
//                     <span className="text-[9px] font-bold text-amber-500 mt-0.5">Awaiting admin review</span>
//                 </div>

//                 <button
//                     onClick={() => onSupport({ ...trip, refId: item._id })}
//                     className="px-8 bg-slate-900 text-slate-100 border border-slate-100 rounded-2xl font-bold hover:bg-slate-950 hover:shadow-lg transition-all uppercase tracking-widest text-[10px]"
//                 >
//                     Support
//                 </button>
//             </div>
//         );
//     }

//     // ── REJECTED: Show rejected badge + allow re-cancel ───────────────────────
//     if (status === 'REJECTED') {
//         return (
//             <div className="flex gap-4 mt-8 flex-wrap">
//                 <Link
//                     to={`/trip/${trip?._id}`}
//                     className="flex-1 text-center bg-indigo-600 text-white py-4 rounded-2xl font-black hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 uppercase tracking-widest text-xs min-w-[140px]"
//                 >
//                     View Full Details
//                 </Link>

//                 <InvoiceButton
//                     trip={trip}
//                     persons={payment?.numPersons || 1}
//                     txnId={payment?.transactionId || item._id}
//                     passengers={payment?.passengers || []}
//                     contact={{
//                         email: payment?.contactEmail,
//                         mobile: payment?.contactMobile,
//                         emergencyName: payment?.emergencyContactName,
//                         emergencyPhone: payment?.emergencyContactPhone
//                     }}
//                 />

//                 <div className="flex flex-col items-center justify-center px-6 py-3 rounded-2xl border-2 border-slate-200 bg-slate-50 min-w-[140px]">
//                     <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Request Rejected</span>
//                     <span className="text-[9px] font-bold text-slate-400 mt-0.5">Contact support</span>
//                 </div>

//                 <button
//                     onClick={() => onSupport({ ...trip, refId: item._id })}
//                     className="px-8 bg-slate-900 text-slate-100 border border-slate-100 rounded-2xl font-bold hover:bg-slate-950 hover:shadow-lg transition-all uppercase tracking-widest text-[10px]"
//                 >
//                     Support
//                 </button>
//             </div>
//         );
//     }

//     // ── DEFAULT: Normal active trip ───────────────────────────────────────────
//     return (
//         <div className="flex gap-4 mt-8 flex-wrap">
//             <Link
//                 to={`/trip/${trip?._id}`}
//                 className="flex-1 text-center bg-indigo-600 text-white py-4 rounded-2xl font-black hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 uppercase tracking-widest text-xs min-w-[140px]"
//             >
//                 View Full Details
//             </Link>

//             <InvoiceButton
//                 trip={trip}
//                 persons={payment?.numPersons || 1}
//                 txnId={payment?.transactionId || item._id}
//                 passengers={payment?.passengers || []}
//                 contact={{
//                     email: payment?.contactEmail,
//                     mobile: payment?.contactMobile,
//                     emergencyName: payment?.emergencyContactName,
//                     emergencyPhone: payment?.emergencyContactPhone
//                 }}
//             />

//             <CancellationManager
//                 trip={trip}
//                 payment={payment}
//                 onSuccess={onLoadData}
//             />

//             <button
//                 onClick={() => onSupport({ ...trip, refId: item._id })}
//                 className="px-8 bg-slate-900 text-slate-100 border border-slate-100 rounded-2xl font-bold hover:bg-slate-950 hover:shadow-lg transition-all uppercase tracking-widest text-[10px]"
//             >
//                 Support
//             </button>
//         </div>
//     );
// };

// const borderColor = (status) => {
//     if (status === 'APPROVED') return 'border-l-rose-400';
//     if (status === 'PENDING')  return 'border-l-amber-400';
//     if (status === 'REJECTED') return 'border-l-slate-400';
//     return 'border-l-indigo-600';
// };
// // ─────────────────────────────────────────────────────────────────────────────
// const HistoryPage = () => {
//     const { user } = useAuth();
//     const [history, setHistory]             = useState([]);
//     const [trips, setTrips]                 = useState([]);
//     const [payments, setPayments]           = useState([]);
//     const [cancellations, setCancellations] = useState([]);
//     const [userMessages, setUserMessages]   = useState([]);
//     const [loading, setLoading]             = useState(true);
//     const [activeTab, setActiveTab]         = useState('history');
//     const [showClearConfirm, setShowClearConfirm] = useState(false);
//     const [showSupportModal, setShowSupportModal] = useState(false);
//     const [selectedTrip, setSelectedTrip]   = useState(null);
//     const [filterState, setFilterState]     = useState({ all: true, created: false, joined: false });

//     const loadData = useCallback(async () => {
//         if (!user?._id) { setLoading(false); return; }
//         try {
//             const [h, t, p, m, c] = await Promise.all([
//                 fetchHistoryByUserId(user._id),
//                 fetchTrip(),
//                 fetchPaymentByUserId(),   // only this user's payments — no cross-user filter needed
//                 getUserMessages(user._id),
//                 getUserCancellations(),
//             ]);
//             setHistory(h.history || []);
//             setTrips(t.trip);
//             setPayments(p.payments || []);
//             setUserMessages(m.data);
//             setCancellations(c || []);
//         } catch (err) {
//             console.error(err);
//         } finally {
//             setLoading(false);
//         }
//     }, [user]);

//     useEffect(() => { if (user?._id) loadData(); }, [user]);

//     const handleCheckboxChange = (name) => {
//         if (name === 'all') {
//             setFilterState({ all: true, created: false, joined: false });
//         } else {
//             setFilterState({ ...filterState, all: false, [name]: !filterState[name] });
//         }
//     };

//     const filteredHistory = history.filter(h => {
//         if (filterState.all) return true;
//         if (filterState.created && h.type === 'CREATED') return true;
//         if (filterState.joined  && h.type === 'JOINED')  return true;
//         return false;
//     });

//     const handleClearHistory = async () => {
//         try {
//             if (activeTab === 'history') {
//                 await clearHistory(user._id);
//                 setHistory([]);
//             } else {
//                 await deleteMessage(user._id);
//                 setUserMessages([]);
//             }
//             setShowClearConfirm(false);
//         } catch (err) {
//             console.error(err);
//             alert(`Failed to clear ${activeTab === 'history' ? 'history' : 'support requests'}`);
//         }
//     };

//     if (loading) {
//         return (
//             <div className="min-h-screen bg-slate-50 flex items-center justify-center">
//                 <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
//             </div>
//         );
//     }

//     return (
//         <div className="min-h-screen bg-slate-50 flex flex-col">
//             <main className="max-w-5xl mx-auto px-4 py-12 flex-grow w-full">

//                 {/* Header */}
//                 <div className="flex flex-col md:flex-row justify-between items-end gap-6 mb-12">
//                     <div>
//                         <h1 className="text-5xl font-black text-slate-900 mb-2 tracking-tight">Travel Journey</h1>
//                         <p className="text-xl text-slate-500 font-medium">Relive your planned and joined adventures.</p>
//                     </div>
//                     <button
//                         onClick={() => setShowClearConfirm(true)}
//                         className="bg-white text-rose-500 border-2 border-rose-100 px-8 py-3 rounded-2xl font-black hover:bg-rose-50 transition-all text-sm uppercase tracking-widest shadow-lg shadow-rose-100"
//                     >
//                         {activeTab === 'history' ? 'Clear My History' : 'Clear Support Requests'}
//                     </button>
//                 </div>

//                 {/* Tabs */}
//                 <div className="flex gap-4 mb-8">
//                     <button
//                         onClick={() => setActiveTab('history')}
//                         className={`px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-xs transition-all ${activeTab === 'history' ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' : 'bg-white text-slate-400 border border-slate-100 hover:bg-slate-50'}`}
//                     >
//                         Trip History
//                     </button>
//                     <button
//                         onClick={() => setActiveTab('support')}
//                         className={`px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-xs transition-all flex items-center gap-3 ${activeTab === 'support' ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' : 'bg-white text-slate-400 border border-slate-100 hover:bg-slate-50'}`}
//                     >
//                         Support Requests ({userMessages?.length})
//                         {userMessages.some(m => m?.status === 'RESOLVED') && (
//                             <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
//                         )}
//                     </button>
//                 </div>

//                 {/* ── TRIP HISTORY TAB ──────────────────────────────────────── */}
//                 {activeTab === 'history' ? (
//                     <>
//                         {/* Filter */}
//                         <div className="flex flex-wrap items-center gap-8 mb-12 bg-white p-8 rounded-[32px] shadow-sm border border-slate-100">
//                             <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Filter Records:</span>
//                             {[
//                                 { key: 'all',     label: 'All Trips' },
//                                 { key: 'created', label: 'Created Trip' },
//                                 { key: 'joined',  label: 'Joined Trips' },
//                             ].map(({ key, label }) => (
//                                 <label key={key} className="flex items-center gap-3 cursor-pointer group">
//                                     <input
//                                         type="checkbox"
//                                         checked={filterState[key]}
//                                         onChange={() => handleCheckboxChange(key)}
//                                         className="w-6 h-6 rounded-lg border-2 border-slate-200 text-indigo-600 focus:ring-indigo-500 transition-all cursor-pointer"
//                                     />
//                                     <span className={`font-bold transition-all ${filterState[key] ? 'text-indigo-600' : 'text-slate-500 group-hover:text-slate-800'}`}>
//                                         {label}
//                                     </span>
//                                 </label>
//                             ))}
//                         </div>

//                         {filteredHistory?.length === 0 ? (
//                             <div className="bg-white rounded-[48px] p-24 text-center border border-slate-100 shadow-xl">
//                                 <div className="text-8xl mb-8 opacity-20">🏜️</div>
//                                 <h2 className="text-3xl font-black text-slate-900 mb-4">No records found</h2>
//                                 <p className="text-slate-500 font-medium mb-10 max-w-sm mx-auto">Either you haven&apos;t booked anything yet or the filters are active.</p>
//                                 <Link to="/join-trip" className="bg-indigo-600 text-white px-12 py-5 rounded-3xl font-black hover:bg-indigo-700 shadow-xl shadow-indigo-100 inline-block transition-all uppercase tracking-widest text-sm">
//                                     Discover Tours
//                                 </Link>
//                             </div>
//                         ) : (
//                             <div className="grid grid-cols-1 gap-8">
//                                 {filteredHistory?.map(item => {
//                                     const trip = trips.find(t => t._id === item?.tripId?._id);
//                                     if (!trip) return null;

//                                     const payment = payments?.find(p => {
//                                         // tripId is stored as raw ObjectId — never populated in this endpoint
//                                         const pid = p?.tripId?.toString?.() ?? String(p?.tripId ?? "");
//                                         return pid === trip?._id?.toString();
//                                     });

//                                     // Find any cancellation for this payment
//                                     const cancellation = cancellations.find(c =>
//                                         c?.paymentId?._id?.toString() === payment?._id?.toString()
//                                         || c?.paymentId?.toString()    === payment?._id?.toString()
//                                     );

//                                     const cancelStatus = cancellation?.status || null;

//                                     return (
//                                         <div
//                                             key={item?._id}
//                                             className={`bg-white rounded-[40px] overflow-hidden shadow-sm hover:shadow-2xl border border-slate-100 flex flex-col md:flex-row transition-all group border-l-8 ${borderColor(cancelStatus)}`}
//                                         >
//                                             {/* ── Image panel ─────────────────────────────────── */}
//                                             <div className="md:w-80 h-48 md:h-auto overflow-hidden relative flex-shrink-0">
//                                                 <img
//                                                     src={trip?.images[0]}
//                                                     className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
//                                                     alt=""
//                                                 />

//                                                 {/* Tint overlay for cancelled/pending */}
//                                                 {cancelStatus && (
//                                                     <div className={`absolute inset-0 ${imageTint(cancelStatus)}`} />
//                                                 )}

//                                                 {/* Trip type badge (top-left) */}
//                                                 <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-md px-4 py-1.5 rounded-full text-[10px] font-black text-indigo-600 uppercase tracking-widest shadow-md z-10">
//                                                     {item?.type === 'CREATED' ? 'AI Planned' : 'Community'}
//                                                 </div>

//                                                 {/* Status badge (bottom-centre) */}
//                                                 <ImageStatusBadge status={cancelStatus} />
//                                             </div>

//                                             {/* ── Content panel ───────────────────────────────── */}
//                                             <div className="flex-grow p-10 flex flex-col justify-between">
//                                                 <div>
//                                                     {/* Title + price row */}
//                                                     <div className="flex justify-between items-start mb-6">
//                                                         <div>
//                                                             <h3 className="text-3xl font-black text-slate-900">{trip?.to}</h3>
//                                                             <p className="text-slate-400 font-bold uppercase text-[10px] tracking-[0.2em] mt-2">
//                                                                 {trip?.from} &bull; {trip?.startDate}
//                                                             </p>
//                                                         </div>
//                                                         <PriceLabel
//                                                             status={cancelStatus}
//                                                             price={trip?.price}
//                                                             type={item?.type}
//                                                         />
//                                                     </div>

//                                                     {/* Info grid */}
//                                                     <div className="grid grid-cols-2 md:grid-cols-4 gap-6 py-6 border-y border-slate-100">
//                                                         <div>
//                                                             <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Departure</p>
//                                                             <p className="text-sm font-bold text-slate-800">{new Date(trip?.startDate).toLocaleDateString()}</p>
//                                                         </div>
//                                                         <div>
//                                                             <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Travel Mode</p>
//                                                             <p className="text-sm font-bold text-slate-800">{trip?.transportMode}</p>
//                                                         </div>
//                                                         <div>
//                                                             <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Ref ID</p>
//                                                             <p className="text-sm font-bold text-slate-800">#{item?._id?.slice(-6)?.toUpperCase()}</p>
//                                                         </div>
//                                                         <div>
//                                                             <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Agency</p>
//                                                             <p className="text-sm font-bold text-slate-800">
//                                                                 {trip?.description?.includes('Organized by')
//                                                                     ? trip?.description?.split('.')[0].replace('Organized by ', '')
//                                                                     : 'AI Planner'}
//                                                             </p>
//                                                         </div>
//                                                     </div>
//                                                 </div>

//                                                 {/* ── Action buttons (smart, based on cancel status) */}
//                                                 <ActionButtons
//                                                     status={cancelStatus}
//                                                     cancellation={cancellation}
//                                                     trip={trip}
//                                                     payment={payment}
//                                                     item={item}
//                                                     onSupport={(t) => { setSelectedTrip(t); setShowSupportModal(true); }}
//                                                     onLoadData={loadData}
//                                                 />
//                                             </div>
//                                         </div>
//                                     );
//                                 })}
//                             </div>
//                         )}
//                     </>
//                 ) : (
//                     /* ── SUPPORT TAB ──────────────────────────────────────────── */
//                     <div className="space-y-12">
//                         <div className="grid grid-cols-1 gap-6">
//                             {userMessages.length === 0 ? (
//                                 <div className="bg-white rounded-[48px] p-24 text-center border border-slate-100 shadow-xl">
//                                     <div className="text-8xl mb-8 opacity-20">📩</div>
//                                     <h2 className="text-3xl font-black text-slate-900 mb-4">No requests found</h2>
//                                     <p className="text-slate-500 font-medium mb-10 max-w-sm mx-auto">You haven&apos;t raised any support tickets yet.</p>
//                                 </div>
//                             ) : (
//                                 userMessages.map(msg => (
//                                     <div key={msg?._id} className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100">
//                                         <div className="flex justify-between items-start mb-6">
//                                             <div className="flex items-center gap-4">
//                                                 <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center text-xl">🎫</div>
//                                                 <div>
//                                                     <h3 className="font-black text-slate-900 text-lg">{msg.subject}</h3>
//                                                     <p className="text-xs font-bold text-slate-400">Raised on {new Date(msg.createdAt).toLocaleString('en-GB')}</p>
//                                                 </div>
//                                             </div>
//                                             <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${msg.status === 'RESOLVED' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
//                                                 {msg.status}
//                                             </span>
//                                         </div>
//                                         <div className="bg-slate-50 p-6 rounded-2xl">
//                                             <p className="text-slate-700 font-medium leading-relaxed">{msg.message}</p>
//                                         </div>
//                                         {msg.status === 'RESOLVED' && (
//                                             <div className="mt-6 p-6 bg-emerald-50 rounded-2xl border border-emerald-100">
//                                                 <div className="flex items-center gap-2 text-emerald-600 font-black text-[10px] uppercase tracking-[0.2em] mb-3">
//                                                     <span className="w-5 h-5 bg-emerald-500 text-white rounded-full flex items-center justify-center text-[10px]">✓</span>
//                                                     Resolution Details
//                                                 </div>
//                                                 <p className="text-slate-700 font-medium leading-relaxed italic">
//                                                     {msg.resolution || "This request has been successfully resolved by our support team."}
//                                                 </p>
//                                             </div>
//                                         )}
//                                     </div>
//                                 ))
//                             )}
//                         </div>

//                         {/* FAQ */}
//                         <div className="mt-20">
//                             <div className="text-center mb-16">
//                                 <h2 className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.4em] mb-4">Support Center</h2>
//                                 <h3 className="text-4xl font-black text-slate-900 tracking-tighter">Frequently Asked Questions</h3>
//                             </div>
//                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//                                 {[
//                                     { q: "How does the AI trip planning work?", a: "Our AI analyzes thousands of data points including weather, local events, and user preferences to generate a custom itinerary in seconds." },
//                                     { q: "Can I modify my itinerary after it's generated?", a: "Yes! You can manually edit any part of your trip, add new stops, or ask the AI to regenerate specific days." },
//                                     { q: "Is my payment information secure?", a: "Absolutely. We use industry-standard encryption and secure payment gateways to ensure your data is always protected." },
//                                     { q: "Do you offer group discounts?", a: "We do! For groups of 10 or more, please contact our corporate travel team for special rates." }
//                                 ].map((faq, i) => (
//                                     <div key={i} className="bg-white p-10 rounded-[40px] border border-slate-100 shadow-sm hover:shadow-md transition-all">
//                                         <h4 className="text-xl font-black text-slate-900 mb-4">{faq.q}</h4>
//                                         <p className="text-slate-500 font-medium leading-relaxed text-sm">{faq.a}</p>
//                                     </div>
//                                 ))}
//                             </div>
//                         </div>
//                     </div>
//                 )}
//             </main>

//             {/* ── Clear confirm modal ───────────────────────────────────────── */}
//             {showClearConfirm && (
//                 <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4">
//                     <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-md" onClick={() => setShowClearConfirm(false)} />
//                     <div className="relative bg-white rounded-[48px] p-12 max-w-md w-full text-center shadow-2xl border-8 border-slate-50">
//                         <div className="w-24 h-24 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
//                             <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
//                                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
//                             </svg>
//                         </div>
//                         <h3 className="text-3xl font-black text-slate-900 mb-4">Clear History?</h3>
//                         <p className="text-slate-500 font-medium mb-10 leading-relaxed text-sm">This will permanently delete your booking records. This action cannot be undone.</p>
//                         <div className="flex flex-col gap-4">
//                             <button onClick={handleClearHistory} className="w-full bg-rose-500 text-white py-4 rounded-3xl font-black hover:bg-rose-600 transition-all shadow-xl shadow-rose-100 uppercase tracking-[0.2em] text-xs">
//                                 Yes, Clear All
//                             </button>
//                             <button onClick={() => setShowClearConfirm(false)} className="w-full bg-slate-100 text-slate-600 py-4 rounded-3xl font-bold hover:bg-slate-200 transition-all uppercase tracking-[0.2em] text-xs">
//                                 Cancel
//                             </button>
//                         </div>
//                     </div>
//                 </div>
//             )}

//             {/* ── Support modal ─────────────────────────────────────────────── */}
//             {showSupportModal && selectedTrip && (
//                 <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4">
//                     <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-md" onClick={() => setShowSupportModal(false)} />
//                     <div className="relative bg-white rounded-[48px] p-12 max-w-lg w-full shadow-2xl border-8 border-indigo-50">
//                         <div className="flex justify-between items-start mb-8">
//                             <div>
//                                 <h3 className="text-3xl font-black text-slate-900 uppercase tracking-tight">Need Help?</h3>
//                                 <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest mt-2">Reference ID: #{selectedTrip.refId?.slice(-6)?.toUpperCase()}</p>
//                             </div>
//                             <button onClick={() => setShowSupportModal(false)} className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 hover:bg-rose-50 hover:text-rose-500 transition-all">✕</button>
//                         </div>
//                         <div className="space-y-6 mb-10">
//                             <div className="p-6 bg-indigo-50 rounded-3xl border border-indigo-100">
//                                 <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-3">Trip Destination</p>
//                                 <p className="text-xl font-black text-indigo-900">{selectedTrip?.to}</p>
//                             </div>
//                             <div className="grid grid-cols-1 gap-4">
//                                 <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
//                                     <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-xl shadow-sm">📧</div>
//                                     <div>
//                                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Support Email</p>
//                                         <p className="font-bold text-slate-700">support@tripplanner.ai</p>
//                                     </div>
//                                 </div>
//                                 <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100">
//                                     <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-xl shadow-sm">📞</div>
//                                     <div>
//                                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">24/7 Helpline</p>
//                                         <p className="font-bold text-slate-700">+91 98765 43210</p>
//                                     </div>
//                                 </div>
//                             </div>
//                         </div>
//                         <div className="flex flex-col gap-4">
//                             <Link to="/contact" className="w-full bg-indigo-600 text-white py-5 rounded-3xl font-black text-center hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 uppercase tracking-widest text-xs">
//                                 Raise a Support Ticket
//                             </Link>
//                             <button onClick={() => setShowSupportModal(false)} className="w-full bg-slate-100 text-slate-600 py-5 rounded-3xl font-bold hover:bg-slate-200 transition-all uppercase tracking-widest text-xs">
//                                 Close
//                             </button>
//                         </div>
//                         <p className="mt-8 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">Our team typically responds within 2–4 hours.</p>
//                     </div>
//                 </div>
//             )}

//             <Footer />
//         </div>
//     );
// };

// export default HistoryPage;
